package function;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import ToolKit.MusicPlayer;
import ToolKit.imageGather;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

class EndPanel extends JPanel {
    /**
    	 *
    	 */
    private static final long serialVersionUID = 1L;
    private static final int WINDOW_WIDTH = 1280;
    private static final int WINDOW_HEIGHT = 720;

    public EndPanel(Store s) throws FontFormatException, IOException {
        // create window
        EndPanel ep = this;
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setLayout(null);
        // font
        Font font1 = Font.createFont(Font.TRUETYPE_FONT, EndPanel.class.getResourceAsStream("/res/fonts/Font2.ttf"));
        font1 = font1.deriveFont(30f);
        Font font2 = new Font("Font2", Font.BOLD, 40);
        // define background
        JLabel bg = new JLabel();
        ImageIcon bgImg = new ImageIcon(imageGather.backgroundImg[4].getScaledInstance(WINDOW_WIDTH, WINDOW_HEIGHT, 0));
        bg.setIcon(bgImg);
        bg.setBounds(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
        bg.setOpaque(false);
        TimeControl.epShowing = true;

        if (GamePanel.gameState == 1) {
            // define title
            JLabel menuTitle = new JLabel();
            menuTitle.setText("ROUND END");
            menuTitle.setFont(font1);
            menuTitle.setBounds(40, 150, 600, 100);
            menuTitle.setOpaque(false);

            String expString = "5,0";
            switch (s.tc.point) {
            case 100:
                expString = "1,0";
                break;
            case 95:
                expString = "1,3";
                break;
            case 90:
                expString = "1,7";
                break;
            case 85:
                expString = "2,0";
                break;
            case 80:
                expString = "2,5";
                break;
            case 75:
                expString = "2,7";
                break;
            case 70:
                expString = "3,0";
                break;
            case 65:
                expString = "3,5";
                break;
            case 60:
                expString = "4,0";
                break;
            default:
                expString = "5,0";
            }

            JLabel content2 = new JLabel();
            content2.setText("You get  " + expString + "  in this test");
            content2.setFont(font2);
            content2.setBounds(350, 350, 500, 80);
            content2.setOpaque(false);

            // define buttons
            JButton exit = new JButton("EXIT");
            exit.setBounds(1000, 500, 200, 50);

            MainMenu.setButton(exit);

            JButton conti = new JButton("Continue");
            conti.setBounds(1000, 400, 200, 50);

            MainMenu.setButton(conti);

            // set buttons action
            exit.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    System.exit(0);
                }

            });

            conti.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    GamePanel.gameState = 1;
                    GamePanel.roundState++;
                    s.tc.reload();
                    s.h.createHid();
                    s.tc.phaseStart = System.currentTimeMillis();
                    s.mm.remove(ep);
                    s.gp.setVisible(true);
                    TimeControl.epShowing = false;
                    MusicPlayer.play(1, 0);
                    MusicPlayer.play(1, 1);
                }

            });

            // add com.s
            this.add(exit);
            this.add(conti);
            this.add(menuTitle);
            this.add(content2);

        } else {
            // define title
            JLabel menuTitle = new JLabel();
            menuTitle.setText("GG");
            font2 = font2.deriveFont(88f);
            menuTitle.setFont(font2);
            menuTitle.setBounds(540, 80, 300, 300);
            menuTitle.setOpaque(false);

            JLabel meme = new JLabel();
            ImageIcon memeImg = new ImageIcon(imageGather.memeImg[0].getScaledInstance(200, 200, 0));
            meme.setIcon(memeImg);
            meme.setBounds(510, 250, 300, 300);
            meme.setOpaque(false);

            // define buttons
            JButton exit = new JButton("EXIT");
            exit.setBounds(1000, 500, 200, 50);

            MainMenu.setButton(exit);

            JButton conti = new JButton("Another Try");
            conti.setBounds(1000, 400, 200, 50);
            MainMenu.setButton(conti);

            // set buttons action
            exit.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    System.exit(0);
                }

            });

            conti.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    GamePanel.gameState = 1;
                    GamePanel.roundState = 1;
                    s.tc.reload();
                    s.h.createHid();
                    s.tc.phaseStart = System.currentTimeMillis();
                    s.mm.remove(ep);
                    s.gp.setVisible(true);
                    TimeControl.epShowing = false;
                    MusicPlayer.play(1, 0);
                    MusicPlayer.play(1, 1);
                }
            });

            this.add(exit);
            this.add(conti);
            this.add(meme);
            this.add(menuTitle);
        }

        this.add(bg);
        this.setVisible(true);
    }
}