package function;


 
 
// Player
public class Player{
	
	protected int state = 1;// default 1 : standing
	public int x = 640, y = 100;
	public double xspeed = 2; // speed(PIXEL)*100 per second, speed range from 1 to 3
	public int width = 100, height = 100; // pro. of player
	Store s;
	//player's location:(start at (440,))
	public void setStore(Store s){
        this.s = s;
	}

}



	// public void run(){
	// 	while(true){
	// 		//
	// 		if(left){
	// 			//
	// 			if(hit(Dir_Left)){
	// 				this.xspeed=0;
	// 			}
				
	// 			if(this.x>=0){
	// 				this.x-=this.xspeed;
	// 				this.img= new ImageIcon(ToolKit.imageGather.playerImg[0].getScaledInstance(50, 50, 0));
	// 			}
				
	// 			this.xspeed=5;
	// 		}
			
	// 		//
	// 		if(right){
				
	// 			if(hit(Dir_Right)){
	// 				this.xspeed=0;
	// 			}
	// 			if(this.x<400){
	// 				this.x+=this.xspeed;
	// 				this.img=new ImageIcon("image/mari_right.gif").getImage();
	// 			}
				
	// 			if(this.x>=400){
	// 				gf.bg.x-=this.xspeed;
	// 				for (int i = 0; i <gf.eneryList.size(); i++) {
	// 					Enery enery = gf.eneryList.get(i);
	// 					enery.x-=this.xspeed;
	// 				}
	// 				this.img=new ImageIcon("image/mari_right.gif").getImage();
	// 			}
	// 			this.xspeed=5;
	// 		}
			
	// 		if(up){
 
	// 			if(jumpFlag && !isGravity){
	// 				jumpFlag=false;
	// 				new Thread(){
	// 					public void run(){
	// 						jump();
	// 						jumpFlag=true;
	// 					}
	// 				}.start();
	// 			}
	// 		}
			
	// 		try {
	// 			this.sleep(20);
	// 		} catch (InterruptedException e) {
	// 			e.printStackTrace();
	// 		}
	// 	}
	// }
	
	
	// jump
	// public void jump(){
	// 	int jumpHeigh=0;
	// 	for (int i = 0; i < 200; i++) {
	// 		jumpHeigh++;
	// 		if(hit()){
	// 			break;
	// 		}
	// 		try {
	// 			Thread.sleep(5);
	// 		} catch (InterruptedException e) {
	// 			e.printStackTrace();
	// 		}
	// 	}
	// }
	
	// public boolean hit(String dir){
	// 	Rectangle myrect = new Rectangle(this.x,this.y,this.width,this.height);
	// 	Rectangle rect =null;
		
	// 	for (int i = 0; i < gf.eneryList.size(); i++) {
	// 		Enery enery = gf.eneryList.get(i);
			
	// 		if(dir.equals("Left")){
	// 			rect = new Rectangle(enery.x+2,enery.y,enery.width,enery.height);
	// 		}
	// 		else if(dir.equals("Right")){
	// 			rect = new Rectangle(enery.x-2,enery.y,enery.width,enery.height);
	// 		}
			
	// 		else if(dir.equals("Up")){
	// 			rect = new Rectangle(enery.x,enery.y+1,enery.width,enery.height);
	// 		}else if(dir.equals("Down")){
	// 			rect = new Rectangle(enery.x,enery.y-2,enery.width,enery.height);
	// 		}
	// 		if(myrect.intersects(rect)){
	// 			return true;
	// 		}
	// 	}
		
	// 	return false;
	// }
	
	// public boolean isGravity=false;
	
	// public void Gravity(){
	// 		new Thread(){
	// 			public void run(){
					
	// 				while(true){
	// 					try {
	// 						sleep(10);
	// 					} catch (InterruptedException e) {
	// 						e.printStackTrace();
	// 					}
						
	// 					if(!jumpFlag){
							
	// 					}
						
	// 					while(true){
	// 						if(!jumpFlag){
	// 							break;
	// 						}
							
	// 						if(hit(Dir_Down)){
	// 							break;
	// 						}
							
	// 						if(y>=358){
	// 							isGravity=false;
	// 						}
	// 						else{
	// 							isGravity=true;
	// 							y+=yspeed;
	// 						}
							
	// 						try {
	// 							sleep(10);
	// 						} catch (InterruptedException e) {
	// 							e.printStackTrace();
	// 						}
	// 				}
	// 			}
	// 			}
	// 		}.start();
	
