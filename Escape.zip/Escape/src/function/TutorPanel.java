package function;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import ToolKit.imageGather;

import java.awt.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
class TutorPanel extends JPanel {

    /**
    	 *
    	 */
    private static final long serialVersionUID = 1L;
    private static int TUTOR_WIDTH = 640;
    private static int TUTOR_HEIGHT = 360;

    public TutorPanel() throws FontFormatException, IOException {
        // create window
        setSize(TUTOR_WIDTH, TUTOR_HEIGHT);
        setLayout(null);
        TutorPanel tp = this;
        // font
        Font font1 = Font.createFont(Font.TRUETYPE_FONT, TutorPanel.class.getResourceAsStream("/res/fonts/Font2.ttf"));
        font1 = font1.deriveFont(30f);
        Font font2 = new Font("Font2", Font.BOLD, 20);
        // define background
        JLabel bg = new JLabel();
        ImageIcon bgImg = new ImageIcon(imageGather.backgroundImg[2].getScaledInstance(TUTOR_WIDTH, TUTOR_HEIGHT, 0));
        bg.setIcon(bgImg);
        bg.setBounds(0, 0, TUTOR_WIDTH, TUTOR_HEIGHT);
        bg.setOpaque(false);

        // define title
        JLabel menuTitle = new JLabel();
        menuTitle.setText("Before start");
        menuTitle.setFont(font1);
        menuTitle.setBounds(40, 0, 600, 100);
        menuTitle.setOpaque(false);

        // define contents : /n is not avalible?
        JLabel content1 = new JLabel();
        content1.setText("Press SPACE to jump through the mistakes.");
        content1.setFont(font2);
        content1.setBounds(100, 100, 500, 50);
        content1.setOpaque(false);

        JLabel content2 = new JLabel();
        content2.setText("Get at least 60 points to pass the exam!");
        content2.setFont(font2);
        content2.setBounds(100, 150, 500, 50);
        content2.setOpaque(false);

        // define buttons
        JButton back = new JButton("BACK");
        back.setBounds(400, 300, 200, 50);

        MainMenu.setButton(back);

        // set buttons action
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tp.setVisible(false);
            }

    });

    // add com.s
    this.add(back);
    this.add(menuTitle);
    this.add(content1);
    this.add(content2);
    this.add(bg);
    this.setVisible(false);
}
}