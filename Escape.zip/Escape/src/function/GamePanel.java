package function;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.event.*;

import ToolKit.imageGather;
import java.awt.*;
import java.io.IOException;

public class GamePanel extends JPanel {
    public boolean spacePressed = false;
    private static final long serialVersionUID = 1L;
    private static final int WINDOW_WIDTH = 1280;
    private static final int WINDOW_HEIGHT = 720;
    public static int gameState = 1; // 1 = running, 0 = ending
    public static int roundState = 1;
    Store s;
    Font font;
    
    public void setStore(Store s) {
        this.s = s;
    }

    public GamePanel() throws FontFormatException, IOException { // 初始化

        this.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        this.setLayout(null);

        // define background
        JButton bg = new JButton();
        ImageIcon bgImg = new ImageIcon(
                ToolKit.imageGather.backgroundImg[4].getScaledInstance(WINDOW_WIDTH, WINDOW_HEIGHT, 0));
        bg.setIcon(bgImg);
        bg.setBounds(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);

        // Font
        font = Font.createFont(Font.TRUETYPE_FONT, EndPanel.class.getResourceAsStream("/res/fonts/Font2.ttf"));
        font = font.deriveFont(1, 50f);

        // key-listner
        bg.addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_SPACE && !spacePressed) {
                    spacePressed = true;
                }
            }

        });
        this.add(bg);
        bg.requestFocus();
        this.setVisible(false);

    }

    // some notation:
    // width of whole map is 6000- supposed so :))
    // every 5s should change the speed
    public void paint(Graphics g) {
        super.paint(g);
        // 挨个检测是不是在图内，在的话paint。 然后无限调用repaint刷新画面
        if (gameState == 1) {

            g.setFont(font);
            g.drawString(s.tc.pointString, 1000, 200);

            // System.out.println("drawing player");
            //player part
            if (s.tc.isJumping) {
                g.drawImage(imageGather.playerImg[0], (WINDOW_WIDTH / 2 - 50) - 200, (int) (WINDOW_HEIGHT / 2 - 50 + 200
                        - ((320 - 320 * Math.pow((s.tc.timestamp - 500), 2) / 250000))), this);// draw jump player
            } else {
                g.drawImage(imageGather.playerImg[1], (WINDOW_WIDTH / 2 - 50) - 200, 510, this);// draw player
            }

            //hids part
            for (int i = s.h.leftObject; i <= s.h.rightObject; i++) {
                if (s.h.hids[2][i] == 2) {
                    //System.out.println(200 + (s.h.hids[0][i]) * 155);
                    if (s.h.hids[3][i] == 0) { // is mistake
                        g.drawImage(imageGather.mistakeImg[s.h.hids[4][i]], (s.h.hids[1][i] - s.tc.cursor), 200 + (s.h.hids[0][i]-1) * 155, this);
                    } else {// is bonus
                        g.drawImage(imageGather.bonusImg[s.h.hids[4][i]], s.h.hids[1][i] - s.tc.cursor, 200 + (s.h.hids[0][i]-1) * 155, this);
                    }
                }
            }

            // collosion tips part
            if(s.tc.hitted){
                g.drawImage(imageGather.tipImg[s.tc.hitData[0][2]], s.tc.hitData[0][1]- s.tc.cursor, 200 + (s.tc.hitData[0][0] - 1) * 155, this);
            }
        }

    }
}

/*
 * note : dispatch来控制的 所以别在监听器里写太复杂的东西或者paint里写很复杂的东西
 * version 12/10/2019 3:57 public void paint(Graphics g) { super.paint(g); //
 * to-do : 挨个检测是不是在图内，在的话paint。 然后无限调用repaint刷新画面
 * 
 * if (!s.p.isJumping) { // 正常状态 画出静止小人 g.drawImage(imageGather.playerImg[0],
 * (WINDOW_WIDTH / 2 - 50) - 200, WINDOW_HEIGHT / 2 - 50 + 200, this); //
 * mid-point (440,520) // is } else { // 跳跃状态 通过tc的timestamp来控制跳跃高度/人物位置
 * g.drawImage(imageGather.playerImg[1], (WINDOW_WIDTH / 2 - 50) - 200, (int)
 * (WINDOW_HEIGHT / 2 - 50 + 200 - ((320 - 320 * Math.pow((s.tc.timestamp -
 * 500), 2) / 250000))), this); System.out.println("drawing jumping player"); }
 * }
 */

/*
 * version 2:44pm 2019-12-5 package function;
 * 
 * import javax.swing.ImageIcon; import javax.swing.JButton; import
 * javax.swing.JFrame; import javax.swing.JPanel;
 * 
 * import java.awt.event.*;
 * 
 * import ToolKit.imageGather; import function.Player;
 * 
 * import java.awt.*; import java.io.IOException;
 * 
 * public class GamePanel extends JPanel {
 * 
 * private static final long serialVersionUID = 1L; private static final int
 * WINDOW_WIDTH = 1280; private static final int WINDOW_HEIGHT = 720; private
 * static int gameState = 1; // 1 = running, 0 = ending private Player p;
 * TimeControl tc; // main-controller
 * 
 * public GamePanel(JFrame frame) throws FontFormatException, IOException { //
 * 初始化
 * 
 * this.setSize(WINDOW_WIDTH, WINDOW_HEIGHT); this.setLayout(null);
 * 
 * // define background JButton bg = new JButton(); ImageIcon bgImg = new
 * ImageIcon(
 * ToolKit.imageGather.backgroundImg[4].getScaledInstance(WINDOW_WIDTH,
 * WINDOW_HEIGHT, 0)); bg.setIcon(bgImg); bg.setBounds(0, 0, WINDOW_WIDTH,
 * WINDOW_HEIGHT);
 * 
 * // space-listener bg.addKeyListener(new KeyListener() {
 * 
 * @Override public void keyReleased(KeyEvent e) { if (e.getKeyCode() ==
 * KeyEvent.VK_SPACE) { System.out.println("space pressed"); if (!p.isJumping) {
 * // if player is standing p.state = 0; p.isJumping = true; tc.timestamp = 0;
 * tc.startJump(); System.out.println("jumped"); } } }
 * 
 * @Override public void keyTyped(KeyEvent e) {
 * 
 * }
 * 
 * @Override public void keyPressed(KeyEvent e) {
 * 
 * } });
 * 
 * this.add(bg); this.setVisible(false);
 * 
 * p = new Player(this); // rund-mark tc = new TimeControl(this, p); }
 * 
 * @Override public void paint(Graphics g) { super.paint(g); // to-do :
 * 挨个检测是不是在图内，在的话paint。 然后无限调用repaint刷新画面 g.drawImage(imageGather.playerImg[0],
 * (WINDOW_WIDTH / 2 - 50) - 200, (int)(WINDOW_HEIGHT / 2 - 50 +
 * 0.1*tc.timestamp),this);
 * 
 * repaint(); }
 * 
 * }
 **/

/*
 * listener points.addKeyListener(new KeyListener() {
 * 
 * @Override public void keyReleased(KeyEvent e) {
 * System.out.println("something happend"); if (e.getKeyCode() ==
 * KeyEvent.VK_SPACE) { System.out.println("space pressed"); if (!s.p.isJumping)
 * { // if player is standing s.p.isJumping = true; s.tc.timestamp = 0; try {
 * s.p.startJump(); } catch (InterruptedException e1) { // TODO Auto-generated
 * catch block e1.printStackTrace(); } } } }
 * 
 * @Override public void keyTyped(KeyEvent e) { }
 * 
 * @Override public void keyPressed(KeyEvent e) {
 * 
 * } });
 * 
 * 
 * 
 * 
 * 
 * // versuch des KeyBindings // *
 * this.getInputMap().put(KeyStroke.getKeyStroke("SPACE"), "doSomething"); //
 * this.getActionMap().put("doSomething", new AbstractAction() { // /** // * //
 */
// private static final long serialVersionUID = 1L;

// public void actionPerformed(ActionEvent e) {
// System.out.println("space pressed");
// if (!s.p.isJumping) { // if player is standing
// s.p.isJumping = true;
// s.tc.timestamp = 0;
// try {
// s.p.startJump();
// } catch (InterruptedException e1) {
// // TODO Auto-generated catch block
// e1.printStackTrace();
// }
// }
// }
// });
// */
