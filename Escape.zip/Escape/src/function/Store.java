package function;

public class Store{
    public TimeControl tc;
    public Player p;
    public GamePanel gp;
    public Hid h;
    MainMenu mm;
    
    public Store(TimeControl tc, Player p, GamePanel gp, Hid h, MainMenu mm){
        this.tc = tc;
        this.p = p;
        this.gp = gp;
        this.h = h;
        this.mm = mm;
    }
    public void setGp(GamePanel gp){
        this.gp = gp;
    }
    
}



