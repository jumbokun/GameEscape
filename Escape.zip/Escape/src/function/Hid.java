package function;

import java.util.Arrays;

public class Hid {
    private static final int MISTAKE = 0;
    private static final int BONUS = 1;
    Store s = null;
    public int countOfHid = 0;
    // public List<Hid> = null;
    public int[][] hids = new int[5][30]; // type,x,status，Mistake-type, pic-type
    // quick notation: status : 0 = not exist, 1 = exist, 2 = should be painted now,
    // 3 =
    // out of screen, -1 = used/wasted (already touched),
    int leftObject = 0;
    int rightObject = 0;
    int lastWasted = 0;

    public void setStore(Store s) {
        this.s = s;
    }

    public void createHid() {
        leftObject = 0;
        rightObject = 0;
        lastWasted = 0;

        int count = 0;
        // after weeks of testing, I decide to use manual setting.
        // mistake-type setting
        count = 0;
        while (count < 25) {
            if (Arrays.asList(1, 4, 7, 11, 14, 15, 18, 22, 23, 25).contains(count)) {
                hids[3][count] = 1; // bonus
            } else {
                hids[3][count] = 0;
            }
            count++;
        }

        // barri-type setting
        count = 0;
        while (count < 25) {
            if (Arrays.asList(1, 3, 4, 6, 7, 11, 16, 18, 21, 24).contains(count)) {
                hids[0][count] = 1; // type-1
            } else if (Arrays.asList(2, 8, 10, 14, 15, 20, 23).contains(count)) {
                hids[0][count] = 2;
            } else {
                hids[0][count] = 3;
            }
            count++;
        }
        // change pic type

        count = 0;
        while (count < 25) {
            if (hids[3][count] == 1) { // is bonus
                double d = Math.random();
                int i = (int) (d * 2);
                hids[4][count] = i;
            } else {
                double d = Math.random();
                int i = (int) (d * 4);
                hids[4][count] = i;
            }
            count++;
        }

        // random part
        count = 0;
        while (count < 25) {
            double d = Math.random();
            int i = (int) (d * 2);
            hids[1][count] = 440 + 1920/2 + count * 200;
            hids[2][count] = i; // 0 for not exist. 1 for exist
            count++;
        }

        // delete the non-exist part  ?? will leads to unknown hitbox mistake
        count = 25;
        int i = 0;
        while (i < count) {
            if (hids[2][i] == 0) {
                for (int y = i; y < count - 1; y++) {
                    for (int l = 0; l < 4; l++)
                        hids[l][y] = hids[l][y + 1];
                }
                count--;
            } else {
                i++;
            }
        }
        // end of delelte

        countOfHid = count;
    }

    public void updateHid() {
        // if (rightObject == -1) { // just about to start
        // if (s.tc.cursor + 1920 - hids[1][0] > 0) {
        // hids[2][0] = 2;
        // rightObject = 0;
        // leftObject = 0;
        // }
        // } else {
        if(s.tc.point >= 90){
                for(int i = leftObject; i<rightObject; i++){
                    hids[3][i] = 0;
                }
        }

        // System.out.println("leftObject: " + leftObject);
        // System.out.println("rightObject: " + rightObject);
        // System.out.println("s.tc.cursor " + s.tc.cursor);
        // System.out.println("countOfHid " + countOfHid);
        // System.out.println("hids[2][rightObject + 1]  " + hids[2][rightObject + 1] );
        // System.out.println("leftObject " + leftObject);
        // System.out.println("hids[2][leftObject] " + hids[2][leftObject]);
        // System.out.println("hids[1][leftObject] " + hids[1][leftObject]);
        // System.out.println("leftObject+1 " + (leftObject+1));
        // System.out.println("hids[2][leftObject+1] " + hids[2][leftObject+1]);
        // System.out.println("hids[1][leftObject+1] " + hids[1][leftObject+1]);
        // System.out.println("leftObject+1 " + (leftObject+2));
        // System.out.println("hids[2][leftObject+1] " + hids[2][leftObject+2]);
        // System.out.println("hids[1][leftObject+1] " + hids[1][leftObject+2]);
        // if(s.tc.hitted){
        // System.out.println("hitted");
        // System.out.println("i " + s.tc.hitData[0][4]);
        // System.out.println("i " + s.h.hids[2][s.tc.hitData[0][4]]);
        // System.out.println("hitdataX " + s.tc.hitData[0][1]);
        // System.out.println("hitStartTime " + s.tc.hitStartTime);
        // System.out.println("leftObject " + leftObject);
        // System.out.println("hids[2][leftObject] " + hids[2][leftObject]);
        // System.out.println("hids[1][leftObject] " + hids[1][leftObject]);

        if (rightObject < countOfHid - 1) { // not end yet
            if (s.tc.cursor + 1920 - hids[1][rightObject + 1] > 0 && hids[2][rightObject + 1] == 1) {
                hids[2][rightObject + 1] = 2;
                rightObject++;
            } 

            if (s.tc.cursor - hids[1][leftObject] > 0) {
                hids[2][leftObject] = 3;
                leftObject++;
            }

        } else { // about to end
            if (leftObject < countOfHid - 1) { // not fully end yet
                if (s.tc.cursor - hids[1][leftObject] > 0) {
                    hids[2][leftObject] = 3;
                    leftObject++;
                } 

            } else { // last object to show
                if (s.tc.cursor - hids[1][leftObject] > 0) {
                    GamePanel.roundState = 0; // game-end
                    // to-do- show end panel
                }
            }
        }
    }
}

// if (leftObject < 0) { // just about to start
// leftObject = 0;
// }
// while (0 < leftObject && count < 25) {
// if (hids[2][count] == 2) {
// leftObject = count;
// break;
// }
// count++;
// }
// if (lastWasted >= 0) {
// for (int i = lastWasted; i < leftObject - 1; i++) {
// hids[2][i] = 3;
// }
// }
// count = lastWasted;
// for(count = leftObject; count < rightObject+1 ; count ++){ // update all
// if (s.tc.cursorX + 1920 - s.h.hids[1][count] > 0) { // num.flag should be in
// the screen
// if (s.tc.cursorX - s.h.hids[1][count] > 0) { // already out of screen
// s.h.hids[2][count] = 3;
// lastWasted = count;
// }

// s.h.hids[2][count] = 2;
// count++;
// }
// else{
// break;
// }
// }
// }