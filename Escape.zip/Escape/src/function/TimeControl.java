package function;

import java.awt.FontFormatException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import ToolKit.MusicPlayer;

public class TimeControl implements ActionListener {
    // for game process
    public long gameStart = 0;
    public long gamePlayed = 0;
    public int cursor = 440;
    public static boolean epShowing = false;
    // for jump
    int timestamp = 0;
    long startTime = 0;
    long curTime = 0;
    boolean jumpEnd;
    boolean countDown = false;
    boolean isJumping = false;
    boolean hitted = false;

    int[][] hitData = new int[2][6];
    // for collosion
    int hitTimestamp = 0;
    long hitStartTime = 0;
    long hitCurTime = 0;

    // for changing speed
    int bonusHitted = 0;
    int mistakeHitted = 0;
    boolean SpeedChangeFlag = false;
    long phaseStart = 0;
    long phasePlayed = 0;
    boolean phaseChanging = false;
    int lastCursor = 440;

    // for point
    String pointString = "80";
    int point = 80;
    Store s;

    // for

    public void setStore(Store s) {
        this.s = s;
    }

    // System.out.println("end of jump");
    // s.gp.paint(s.gp.getGraphics());

    @Override
    public void actionPerformed(ActionEvent e) {

        if (point < 0) {
            GamePanel.gameState = 0;
        }

        if (GamePanel.roundState > 0 && GamePanel.gameState == 1) { // while game running
            // jump part start
            if (s.gp.spacePressed && !isJumping) {
                // System.out.println("start jump");
                isJumping = true;
                jumpEnd = false;
                startTime = System.currentTimeMillis();
                timestamp = 0;
            }

            if (isJumping && timestamp < 1000) {
                curTime = System.currentTimeMillis();
                timestamp = (int) (curTime - startTime);
            }

            if (timestamp >= 1000) { // end of a jump
                isJumping = false;
                s.gp.spacePressed = false; // release the lock of space
                timestamp = 0; // reset timestamp
            }
            // jump part end

            // update some UI-required numbers
            phasePlayed = System.currentTimeMillis() - phaseStart;
            cursor = (int) (lastCursor + phasePlayed
                    * (s.p.xspeed + (0.1 * bonusHitted - 0.1 * mistakeHitted) * GamePanel.roundState * 2) * 100 / 1000);
            pointString = String.valueOf(point);

            // update hid
            s.h.updateHid();

            /* Impact checking */
            int i = s.h.leftObject;
            while (i <= s.h.rightObject) {
                int PlayerY = (int) (720 / 2 + 200 - ((320 - 320 * Math.pow((s.tc.timestamp - 500), 2) / 250000))); // default
                                                                                                                    // 560
                if (s.h.hids[2][i] == 2) {
                    // uphit
                    if (Math.abs(s.h.hids[1][i] - cursor - 390) < 50 && s.h.hids[2][i] == 2) {
                        if (Math.abs(PlayerY - 225 - (s.h.hids[0][i] - 1) * 155) < 25) {
                            hitting(i);
                        }
                    }
                    // bothit
                    if (Math.abs(s.h.hids[1][i] - cursor - 390) < 50 && s.h.hids[2][i] == 2) {
                        if (Math.abs(PlayerY - (225 + (s.h.hids[0][i] - 1) * 155)) <= 25) {
                            hitting(i);
                        }
                    }
                }
                i++;
            }

            // phase-check
            if (SpeedChangeFlag) {
                SpeedChangeFlag = false;
                phaseStart = System.currentTimeMillis();
                lastCursor = cursor;
            }

            // hit-paint-check
            hitCurTime = System.currentTimeMillis();
            if (hitCurTime - hitStartTime < 1000) {
                hitted = true;
            } else {
                hitData[0][3] = 0;
                hitted = false;
            }
            // System.out.println("start repaint");
            s.gp.repaint();
        }

        if ((GamePanel.roundState == 0 || GamePanel.gameState == 0) && !epShowing) { // game over and ep not painted yet
            // create ep and add it to jframe
            EndPanel ep = null;
            try {
                ep = new EndPanel(s);
            } catch (FontFormatException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            s.mm.add(ep);
            s.gp.setVisible(false);
        } // this Thread should end automatically
    }

    public void hitting(int i) {
        if (s.h.hids[3][i] == 0) { // is mistake
            hitMistake(s.h.hids[0][i]);
        } else { // is bonus
            hitBonus(s.h.hids[0][i]);
        }
        s.h.hids[2][i] = -1; // make this hid used
        hitData[0][0] = s.h.hids[0][i]; // record y(type)
        hitData[0][1] = s.h.hids[1][i]; // record x
        hitData[0][3] = 1; // should be painted
        hitData[0][4] = i;
        hitStartTime = System.currentTimeMillis();
        SpeedChangeFlag = true;
    }

    public void hitMistake(int type) {
        point -= 10;
        hitData[0][2] = 0;
        mistakeHitted++;
        
        MusicPlayer.play(0, 0);
        MusicPlayer.play(0, 1);
    }

    public void hitBonus(int type) {
        point += 5;
        hitData[0][2] = 1;
        bonusHitted++;
        MusicPlayer.play(0, 0);
        MusicPlayer.play(0, 1);
    }

    public void reload() {
        gameStart = 0;
        gamePlayed = 0;
        cursor = 440;

        // for jump
        timestamp = 0;
        startTime = 0;
        curTime = 0;
        countDown = false;
        isJumping = false;
        hitted = false;

        hitData = new int[2][6];
        // for collosion
        hitTimestamp = 0;
        hitStartTime = 0;
        hitCurTime = 0;

        // for changing speed
        bonusHitted = 0;
        mistakeHitted = 0;
        SpeedChangeFlag = false;
        phaseStart = 0;
        phasePlayed = 0;
        phaseChanging = false;
        lastCursor = 440;

        // for point
        pointString = "80";
        point = 80;
    }

    // public void run() {
    // while (GamePanel.gameState == 1) { // while game running
    // s.tc.gamePlayed = System.currentTimeMillis() - s.tc.gameStart;
    // s.tc.cursor = (int) (s.tc.gamePlayed * s.p.xspeed * 100 / 1000);
    // s.gp.repaint();
    // }
    // if(GamePanel.gameState == 0){ // game over
    // s.gp.setVisible(false);
    // } // this Thread should end automatically
    // }

}
