package function;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;

import ToolKit.MusicPlayer;
import function.GamePanel;
import function.Hid;
import function.Player;
import function.Store;
import function.TimeControl;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class MainMenu extends JFrame {
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private static int WINDOW_WIDTH = 1280;
    private static int WINDOW_HEIGHT = 720;
    private static int TUTOR_WIDTH = 640;
    private static int TUTOR_HEIGHT = 360;

    /**
     * @throws IOException
     * @throws FontFormatException
     * 
     */

    public MainMenu() throws FontFormatException, IOException {
        setDefaultLookAndFeelDecorated(true);
        this.setFocusable(true);
        // create window
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setResizable(false);
        this.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);

        //create music player
        MusicPlayer mp = new MusicPlayer();
        // font
        Font font2 = Font.createFont(Font.TRUETYPE_FONT, MainMenu.class.getResourceAsStream("/res/fonts/Font2.ttf"));
        font2 = font2.deriveFont(60f);

        // define background
        JLabel bg = new JLabel();
        ImageIcon bgImg = new ImageIcon(
                ToolKit.imageGather.backgroundImg[0].getScaledInstance(WINDOW_WIDTH, WINDOW_HEIGHT, 0));
        bg.setIcon(bgImg);
        bg.setBounds(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);

        // define title
        JLabel menuTitle = new JLabel();
        menuTitle.setText("Escape");
        menuTitle.setFont(font2);
        menuTitle.setBounds(440, 200, 600, 300);

        // define buttons
        JButton start = new JButton("START");
        start.setBounds(565, 400, 150, 50);
        JButton tutorial = new JButton("TUTORIAL");
        tutorial.setBounds(540, 500, 200, 50);
        JButton exit = new JButton("EXIT");
        exit.setBounds(1050, 600, 100, 50);

        setButton(start);
        setButton(tutorial);
        setButton(exit);

        
        // define help panel
        TutorPanel tjp = new TutorPanel();
        tjp.setBounds(300, 300, TUTOR_WIDTH, TUTOR_HEIGHT);
        tjp.setVisible(false);

        // set store s
        Hid h = new Hid();
        TimeControl tc = new TimeControl();
        Player p = new Player();
        Store s = new Store(tc, p, null, h, this);
        p.setStore(s);
        tc.setStore(s);
        h.setStore(s);

        GamePanel gp = new GamePanel();
        gp.setBounds(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
        gp.setStore(s);
        s.setGp(gp);

        // define game panel
        // begin

        // set buttons action
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        tutorial.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // this.setOpacity(0.2f);
                tjp.setVisible(true);
                MusicPlayer.play(1, 0);
                MusicPlayer.play(1, 1);
            }
        });
        
        
        start.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // gjp.startGame();
                //s.mm.removeAll();
                GamePanel.gameState = 1;
                GamePanel.roundState = 1;
                s.tc.reload();
                s.h.createHid();
                s.mm.remove(tjp);
                s.mm.getContentPane().removeAll();
                s.tc.phaseStart = System.currentTimeMillis();

                Timer timer = new Timer(10, s.tc);
                timer.start();
                s.mm.add(gp);
                gp.setVisible(true);
                // System.out.println("invokered from main");
                MusicPlayer.play(1, 0);
                MusicPlayer.play(1, 1);
            }
        });

        //add com.s
        this.add(tjp);
        this.getContentPane().add(start);
        this.getContentPane().add(tutorial);
        this.getContentPane().add(exit);
        this.getContentPane().add(menuTitle);
        this.getContentPane().add(bg);
        this.setVisible(true);

        //sounds
       //MusicPlayer.play(2, 0);
       //MusicPlayer.play(2, 1);
    }

    public static void setButton(JButton b) throws FontFormatException, IOException {
        Font fontButton = Font.createFont(Font.TRUETYPE_FONT, MainMenu.class.getResourceAsStream("/res/fonts/Font2.ttf"));
        fontButton = fontButton.deriveFont(1, 12f);
        b.setFont(fontButton);
        b.setOpaque(false);
        // b.setBorder(null);
        b.setContentAreaFilled(false);
    }

    public static void main(String[] args) throws FontFormatException, IOException {
        MainMenu mm = new MainMenu();
    }
}
