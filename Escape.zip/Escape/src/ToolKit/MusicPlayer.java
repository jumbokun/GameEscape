package ToolKit;

import java.io.IOException;
import java.io.InputStream;

import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

public class MusicPlayer{
	
	public static int musicNumbers = 2;
	public static AudioStream []BGM = new AudioStream[musicNumbers];
	boolean flag;
	private static InputStream fileInputStream[] = new InputStream[musicNumbers];
	private static String[] path = new String[musicNumbers];
	
	public MusicPlayer() {
		flag = true;
		try {
			path[0] =  "ding.wav";
			path[1] =  "pong.wav";

			for(int i =0;i < path.length;i++) {
				fileInputStream[i] = MusicPlayer.class.getResourceAsStream(path[i]);
				BGM[i] = new AudioStream(fileInputStream[i]);
			}
		} catch (IOException e) {e.printStackTrace();}
	}
	
	//play Music
	public static void play(int i ,int isIn) {
		try {
			if (isIn == 0) {
				AudioPlayer.player.start(BGM[i]);
			}else if (isIn == 1) {
				AudioPlayer.player.start(BGM[i]);
				fileInputStream[i] = MusicPlayer.class.getResourceAsStream(path[i]);
				BGM[i] = new AudioStream(fileInputStream[i]);
			}else {
				fileInputStream[i] = MusicPlayer.class.getResourceAsStream(path[i]);
				BGM[i] = new AudioStream(fileInputStream[i]);
			}
		} catch (Exception e) {e.printStackTrace();}
		
	}

	//pause
	public void stop(AudioStream music) {
		AudioPlayer.player.stop(music);
		flag = false;
	}
}
