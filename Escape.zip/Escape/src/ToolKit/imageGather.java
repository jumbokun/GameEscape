package ToolKit;

import java.awt.Image;
import java.awt.Toolkit;

public class imageGather {

	public static Image backgroundImg[] = new Image[] {
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/MainBG.png")),
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/escape.png")),
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/HelpBG.png")),
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/tutorialBubble.png")),
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/GameBG.png"))
	};

	public static Image mistakeImg[] = new Image[] {
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/mistake1.png")),
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/mistake2.png")),
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/mistake3.png")),
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/mistake4.png")),
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/mistake5.png")),
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/mistake5.png"))
	};

	public static Image playerImg[] = new Image[] {
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/player1.png")),
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/player2.png"))
	};

    public static Image bonusImg[] = new Image[] {
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/bonus.png")),
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/bonus1.png")),
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/bonus2.png")),
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/bonus2.png")),
	};

    public static Image tipImg[] = new Image[] {
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/tip2.png")),
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/tip1.png")),
	};

    public static Image memeImg[] = new Image[] {
		Toolkit.getDefaultToolkit().getImage(imageGather.class.getResource("/res/images/meme.png")),
	};


}