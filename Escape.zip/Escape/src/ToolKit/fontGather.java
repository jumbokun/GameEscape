package ToolKit;

import java.awt.Font;
import java.awt.FontFormatException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class fontGather {
    public static Font font1;
    public static Font font2;
    // hash map
    public static Map<String, Font> fontCollector = new HashMap<String, Font>();

    public fontGather() throws FontFormatException, IOException {
        font1 = Font.createFont(Font.TRUETYPE_FONT, fontGather.class.getResourceAsStream(".\\res\\fonts\\Font1.ttf"));
        font1 = font1.deriveFont(72.0f);
        font2 = Font.createFont(Font.TRUETYPE_FONT, fontGather.class.getResourceAsStream(".\\res\\fonts\\Font2.ttf"));
        font2 = font2.deriveFont(72f);
        //System.out.print("Init completed.");
        fontCollector.put("font1", font1);
        fontCollector.put("font2", font2);
    }
    

	public Font setFontSize(Font f,float size) {
		return f.deriveFont(size);
	}
	
}